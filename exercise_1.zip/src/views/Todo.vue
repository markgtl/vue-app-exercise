<template>
  <div class="todo">
    <logo />
    <!-- in the example component we emitted an methodToCall with some data from the input field, 
        when the methodToCall is called it calls the consoleLogData function  -->
    <example-component @methodToCall="consoleLogData" exampleProp1='example' />
    <div class="todos-container">
    </div>
    <!-- the receivedText is displayed here -->
    <h3 class="text">{{receivedText}}</h3>
  </div>
</template>

<script lang="ts">
// @ is an alias to /src
import { Vue, Component, Prop } from 'vue-property-decorator';
// This is how you import a component, the double dots means you navigate one folder up and than to the components folder
import ExampleComponent from '../components/ExampleComponent.vue';
import Logo from '../components/Logo.vue';

// Here you can add components to your current component
@Component({ components: { ExampleComponent, Logo } })
export default class Todo extends Vue {
  receivedText = ''

  // this function binds the data send from the example component to the variable receivedText, this text is then displayed in line 11
  consoleLogData(payload: any) {
    this.receivedText = payload;
  }
}
</script>
<style scoped>
.todo {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 400px;
  background-color: hsla(0, 0%, 90%, 1);
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  border-radius: 10px;
  min-height: 500px;
}

.todos-container {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  width: 70%;
}
.text {
  color: #435365;
}
</style>
