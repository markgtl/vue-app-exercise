<template>
  <!-- class can be used in <style>  your element -->
  <div class="example">
    <!-- input is an field where you can type v-model is used to bind(save) the data to a variable see line 24 -->
    <input class="input" type="text" v-model="inputText" />
    <!--@click is an action handler if you click this button the sendData function will be called (line 26) -->
    <button @click="sendData" class="button">Send Data</button>
    <!--{{}} is used to display data from the <script> part-->
  </div>
</template>
<!-- the <script> tag is used to write javascript/typescript -->
<script lang="ts">
// @ is an alias to /src
import { Vue, Component, Prop } from 'vue-property-decorator';

@Component({ components: {} })
export default class ExampleComponent extends Vue {
  // Prop is used to receive data in this component you need to give at an data type and default value, on the right side op the () you give it an name
  @Prop({ type: String, default: '' }) exampleProp1;
  @Prop({ type: Number, default: null }) exampleProp2;
  // this is how a variable is declared
  inputText = '';
  // this is an javascript function
  sendData() {
    // this emit does actually what is says, it emits data from this component to the upper component, it calls the function methodTocall
    // and send the inputText from line 5 to that function.
    this.$emit('methodToCall', this.inputText);
  }
}
</script>

<!--style tag is used to style the page with css, google most used css properties for usefull properties 
    an element in the <template> tag can be selected by adding a class to the element in the <template>
    and 'select' it by using the name of the class with an dot(.) in the front
-->
<style scoped>
.example {
  margin: 5px;
}
.input {
  border-radius: 2px;
  border: none;
  padding: 3px;
}
</style>
