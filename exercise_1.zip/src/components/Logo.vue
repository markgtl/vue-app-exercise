<template>
  <div class="logo">
    <div class="img-container">
      <img class="image" alt="Vue logo" src="../assets/logo.png" />
    </div>
  </div>
</template>

<script lang="ts">
// @ is an alias to /src
import { Vue, Component, Prop } from "vue-property-decorator";

@Component({ components: {} })
export default class Logo extends Vue {}
</script>

<style scoped>
.logo {
  height: 120px;
  width: 120px;
  border-radius: 120px;
  content: "";
  background-color: white;
  margin-top: 20px;
  margin-bottom: 20px;
}
.img-container {
  content: "";
  margin: auto;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.image {
  max-width: 100%;
  max-height: 100%;
  border-radius: 50px;
}
</style>
