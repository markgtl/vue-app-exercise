<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png" />
    <HelloWorld msg="Welcome to Your Vue.js App" />
  </div>
</template>

<script lang="ts">
// @ is an alias to /src
import { Vue, Component, Prop } from 'vue-property-decorator';

@Component({components: {}})
export default class Home extends Vue  {
  @Prop({type: String, default: ''}) exampleProp1;
  @Prop({type: Number, default: ''}) exampleProp2;
}
</script>
<style scoped>
</style>
