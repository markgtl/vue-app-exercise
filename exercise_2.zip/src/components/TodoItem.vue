<template>
  <div class="todo-item">
    <div> {{text}}</div>
    <button class="button">Delete</button>
  </div>
</template>

<script lang="ts">
// @ is an alias to /src
import { Vue, Component, Prop } from 'vue-property-decorator';

@Component({ components: {} })
export default class TodoItem extends Vue {
  @Prop({ type: String, default: '' }) text;
  @Prop({ type: Number, default: '' }) id;
}
</script>

<style scoped>
.todo-item {
  display: flex;
  justify-content: space-between;
  margin: 5px;
  background-color: hsla(0, 0%, 92%, 1);
  padding: 10px;
  width: 100%;
  border-radius: 5px;
  color: #41b883;
}
</style>
