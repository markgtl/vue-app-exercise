<template>
  <div class="example">
    <input type="text" v-model="inputText" />
    <button @click="sendData" class="button">Send Data</button>
  </div>
</template>

<script lang="ts">
// @ is an alias to /src
import { Vue, Component, Prop } from 'vue-property-decorator';

@Component({ components: {} })
export default class ExampleComponent extends Vue {
  @Prop({ type: String, default: '' }) exampleProp1;
  @Prop({ type: Number, default: null }) exampleProp2;

  inputText = '';
  
  sendData() {
    this.$emit('methodToCall', this.inputText);
  }
}
</script>

<style scoped>
.example {
    margin:5px;
  margin: 5px;
}
.input {
  border-radius: 2px;
  border: none;
  padding: 2px;
}

</style>
